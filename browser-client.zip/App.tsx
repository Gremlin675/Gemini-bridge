import React, { useState, useEffect, useRef, useCallback } from 'react';
import { type WebSocketMessage, ConnectionStatus as ConnectionStatusEnum, Job } from './types';
import { gemini_request } from './services/geminiService';
import ConnectionStatus from './components/ConnectionStatus';
import InitialState from './components/InitialState';
import JobCard from './components/JobCard';

const WEBSOCKET_URL = 'ws://localhost:8765';
const RECONNECT_INTERVAL = 4000;

const App: React.FC = () => {
    const [connectionStatus, setConnectionStatus] = useState<ConnectionStatusEnum>(ConnectionStatusEnum.CONNECTING);
    const [showHelp, setShowHelp] = useState(false);
    const [jobs, setJobs] = useState<Job[]>([]);
    const [error, setError] = useState<string | null>(null);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    // ---------------------------------------------------------------------------
    // Error classification
    // ---------------------------------------------------------------------------
    const classifyGeminiError = (e: unknown): { type: 'internal' | 'usage_limit' | 'rpc' | 'other'; message: string } => {
        let message = 'Unknown error';

        if (e instanceof Error) message = e.message;
        else if (typeof e === 'string') message = e;
        else if (e && typeof e === 'object') {
            const obj = e as Record<string, unknown>;
            message = (obj.message as string) ?? (((obj.error as Record<string, unknown>)?.message) as string) ?? JSON.stringify(e);
        }

        const lower = message.toLowerCase();

        if (lower.includes('failed to fetch') || lower.includes('network request failed') || lower.includes('econnreset')) {
            return { type: 'rpc', message };
        }
        if (lower.includes('429') || lower.includes('resource_exhausted') || lower.includes('quota') || lower.includes('too many requests')) {
            return { type: 'usage_limit', message };
        }
        if (lower.includes('500') || lower.includes('503') || lower.includes('internal') || lower.includes('overloaded') || lower.includes('unavailable')) {
            return { type: 'internal', message };
        }

        return { type: 'other', message };
    };

    // ---------------------------------------------------------------------------
    // Job processor
    // ---------------------------------------------------------------------------
    const processJob = async (job: Job) => {
        try {
            const result = await gemini_request(
                job.originalImages.map(img => ({ data: img.data, mimeType: img.mimeType })),
                job.prompt,
                job.jobSource,
                job.model,
            );

            setJobs(prev => prev.map(j => j.id === job.id ? { ...j, editedResult: result, isLoading: false } : j));

            if ((result.image || result.text) && wsRef.current && wsRef.current.readyState === 1) {
                if (job.jobSource === 'txt_request') {
                    wsRef.current.send(JSON.stringify({ type: 'txt_result', job_id: job.id, text: result.text ?? 'Done' }));
                } else {
                    wsRef.current.send(JSON.stringify({ type: 'image_result', job_id: job.id, image_data: result.image ?? undefined }));
                }
            }
        } catch (e) {
            const { type, message } = classifyGeminiError(e);

            setJobs(prev => prev.map(j => j.id === job.id ? { ...j, error: `[${type.toUpperCase()}] ${message}`, isLoading: false } : j));

            if (wsRef.current && wsRef.current.readyState === 1) {
                const payload: WebSocketMessage = {
                    type: 'error',
                    job_id: job.id,
                    error_type: type,
                    message,
                    client_id: `browser_${Date.now()}`,
                };
                wsRef.current.send(JSON.stringify(payload));
            }
        }
    };

    // ---------------------------------------------------------------------------
    // WebSocket lifecycle with auto-reconnect
    // ---------------------------------------------------------------------------
    const connect = useCallback(() => {
        if (reconnectTimer.current) {
            clearTimeout(reconnectTimer.current);
            reconnectTimer.current = null;
        }

        setConnectionStatus(ConnectionStatusEnum.CONNECTING);
        const ws = new WebSocket(WEBSOCKET_URL);
        wsRef.current = ws;

        ws.onopen = () => {
            setConnectionStatus(ConnectionStatusEnum.CONNECTED);
            setError(null);
            ws.send(JSON.stringify({ type: 'browser' }));
        };

        ws.onmessage = event => {
            if (event.data === 'pong' || event.data === 'ok') return;

            let message: WebSocketMessage;
            try {
                message = JSON.parse(event.data);
            } catch {
                console.error('Failed to parse WebSocket message:', event.data.substring(0, 200));
                return;
            }

            const buildJob = (source: 'txt_request' | 'image_request'): Job => ({
                id: message.job_id!,
                jobSource: source,
                originalImages: (message.images ?? []).map((img, i) => ({
                    data: img.data ?? '',
                    mimeType: img.mime_type,
                    originalPath: img.name ?? `image_${i}`,
                })),
                prompt: message.prompt!,
                model: message.model,
                editedResult: null,
                isLoading: true,
                error: null,
            });

            if ((message.type === 'txt_request' || message.type === 'image_request') && message.job_id && message.prompt) {
                const newJob = buildJob(message.type);
                setJobs(prev => [...prev, newJob]);
                processJob(newJob);
            }
        };

        ws.onerror = () => {
            setError(`Could not connect to ${WEBSOCKET_URL}.`);
            setConnectionStatus(ConnectionStatusEnum.DISCONNECTED);
        };

        ws.onclose = () => {
            setConnectionStatus(ConnectionStatusEnum.DISCONNECTED);
            reconnectTimer.current = setTimeout(connect, RECONNECT_INTERVAL);
        };
    }, []);

    useEffect(() => {
        connect();
        return () => {
            if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
            wsRef.current?.close();
        };
    }, [connect]);

    // ---------------------------------------------------------------------------
    // Render
    // ---------------------------------------------------------------------------
    return (
        <div className="min-h-screen bg-brand-primary text-brand-text font-sans p-4 sm:p-6 lg:p-8">
            <div className="container mx-auto">
                <header className="flex flex-col sm:flex-row justify-between items-center mb-6 pb-4 border-b border-brand-secondary">
                    <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2 sm:mb-0">
                        Nano Banana <span className="text-brand-accent">Processor</span>
                    </h1>
                    <div className="flex items-center space-x-4">
                        <button
                            onClick={() => setShowHelp(true)}
                            className="flex items-center space-x-2 px-3 py-1.5 rounded-full text-sm font-medium bg-brand-secondary hover:bg-slate-600 text-slate-300 transition-colors"
                        >
                            <span>Server Help</span>
                        </button>
                        <ConnectionStatus status={connectionStatus} />
                    </div>
                </header>

                <main>
                    {error && (
                        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg mb-6">
                            <strong>Error: </strong>{error}
                        </div>
                    )}
                    {jobs.length === 0 && !error && <InitialState />}
                    {jobs.length > 0 && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {jobs.map(job => <JobCard key={job.id} job={job} />)}
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;