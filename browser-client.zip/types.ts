import { GeminiEditResult } from "./services/geminiService";

export enum ConnectionStatus {
    CONNECTING = 'connecting',
    CONNECTED = 'connected',
    DISCONNECTED = 'disconnected',
}

export interface OriginalImage {
    data: string;     // base64-encoded
    mimeType: string;
    originalPath: string;
}

export interface WebSocketMessage {
    type:
        | 'txt_request'
        | 'txt_result'
        | 'image_request'
        | 'image_result'
        | 'resource_exhausted'
        | 'error'
        | 'browser';

    job_id?: string;

    images?: Array<{
        data?: string;
        name?: string;
        mime_type: string;
    }>;

    prompt?: string;
    model?: string;

    // Result fields
    image_data?: string;
    text?: string;
    client_id?: string;

    // Error fields
    error_type?: 'internal' | 'usage_limit' | 'rpc' | 'other';
    message?: string;
}

export interface Job {
    id: string;
    jobSource: 'txt_request' | 'image_request';
    originalImages: OriginalImage[];
    prompt: string;
    model?: string;
    editedResult: GeminiEditResult | null;
    isLoading: boolean;
    error: string | null;
}