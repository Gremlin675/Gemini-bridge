import { GoogleGenAI, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;
if (!API_KEY) throw new Error("API_KEY environment variable is not set.");

export interface GeminiEditResult {
    image: string | null;
    text: string | null;
}

interface InputImage {
    data: string;
    mimeType: string;
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const normalizeModelName = (name: string): string => {
    if (name === 'gemini-3-pro')        return 'gemini-3-pro-preview';
    if (name === 'gemini-3-flash')      return 'gemini-3-flash-preview';
    if (name.includes('flash-image'))   return 'gemini-2.5-flash-image';
    return name;
};

const stripBase64Prefix = (data: string): string =>
    data.replace(/^data:image\/\w+;base64,/, '');

export const gemini_request = async (
    images: InputImage[],
    prompt: string,
    request_type: string = 'txt_request',
    modelName: string = 'gemini-2.5-flash-image',
): Promise<GeminiEditResult> => {
    const model = normalizeModelName(modelName);

    const imageParts = images.map(img => ({
        inlineData: {
            data: stripBase64Prefix(img.data),
            mimeType: img.mimeType || 'image/jpeg',
        },
    }));

    const parts = [...imageParts, { text: prompt || ' ' }];

    if (request_type === 'txt_request') {
        const response = await ai.models.generateContent({
            model,
            contents: [{ parts }],
        });
        return { image: null, text: response.text ?? null };
    }

    // Image generation / editing
    const response = await ai.models.generateContent({
        model,
        contents: [{ parts }],
        config: { responseModalities: [Modality.IMAGE, Modality.TEXT] },
    });

    const responseParts = response.candidates?.[0]?.content?.parts ?? [];
    const imagePart = responseParts.find(p => p.inlineData);
    const textPart  = responseParts.find(p => p.text);

    const result: GeminiEditResult = {
        image: imagePart?.inlineData?.data ?? null,
        text:  textPart?.text ?? null,
    };

    if (!result.image && !result.text) {
        throw new Error('Gemini returned neither an image nor text.');
    }

    return result;
};