
import React from 'react';

const InitialState: React.FC = () => {
    return (
        <div className="text-center py-16 px-6 bg-brand-secondary rounded-lg border-2 border-dashed border-slate-600">
            <svg className="mx-auto h-12 w-12 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <h2 className="mt-2 text-2xl font-semibold text-white">Waiting for Instructions</h2>
            <p className="mt-2 text-slate-400">
                This application is listening for a command from your local server.
            </p>
            <p className="mt-1 text-slate-400">
                Please send an image and a prompt to the WebSocket at <code className="bg-brand-primary px-1.5 py-0.5 rounded text-brand-accent font-mono text-sm">ws://localhost:8765</code>.
            </p>
        </div>
    );
};

export default InitialState;
