
import React from 'react';

interface PromptDisplayProps {
    prompt: string;
}

const PromptDisplay: React.FC<PromptDisplayProps> = ({ prompt }) => {
    return (
        <div className="mt-4 p-4 bg-brand-secondary rounded-lg shadow-md border border-slate-700/50">
            <h3 className="font-semibold text-sm text-brand-accent mb-2">PROMPT</h3>
            <p className="text-brand-text italic">"{prompt}"</p>
        </div>
    );
};

export default PromptDisplay;
