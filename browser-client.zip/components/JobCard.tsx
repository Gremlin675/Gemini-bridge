import React from 'react';
import { Job } from '../types';
import PromptDisplay from './PromptDisplay';

interface JobCardProps {
    job: Job;
}

const LoadingSpinner: React.FC = () => (
    <div className="absolute inset-0 flex items-center justify-center bg-brand-secondary/80 backdrop-blur-sm z-30">
        <div className="flex flex-col items-center">
            <svg className="animate-spin h-10 w-10 text-brand-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-4 text-lg font-medium text-brand-text">Thinking...</p>
        </div>
    </div>
);

const JobCard: React.FC<JobCardProps> = ({ job }) => {
    const isImageJob = job.jobSource === 'image_request';

    return (
        <div className="bg-brand-secondary/50 p-4 rounded-lg border border-slate-700/50 flex flex-col space-y-4">
            <div className="flex justify-between items-start">
                <div className="bg-brand-primary px-2 py-1 rounded text-xs text-slate-400 font-mono border border-slate-700">
                    {job.model || (isImageJob ? 'gemini-2.5-flash-image' : 'gemini-3-pro-preview')}
                </div>
                <div className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider ${isImageJob ? 'bg-purple-900/50 text-purple-200 border border-purple-700' : 'bg-blue-900/50 text-blue-200 border border-blue-700'}`}>
                    {isImageJob ? 'Image Edit' : 'Text Gen'}
                </div>
            </div>

            <PromptDisplay prompt={job.prompt} />

            {isImageJob && (
                <div>
                    <h3 className="font-semibold text-sm text-brand-accent mb-2 uppercase">Original Images</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 rounded-lg bg-brand-primary p-2 border border-slate-700/50">
                        {job.originalImages.map((img, index) => (
                            <div key={index} className="relative aspect-square rounded-md overflow-hidden border border-slate-700">
                                <img src={`data:${img.mimeType};base64,${img.data}`} alt={`Original ${index + 1}`} className="w-full h-full object-cover" />
                                {img.originalPath && (
                                    <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs p-1 truncate" title={img.originalPath}>
                                        {img.originalPath.split(/[\\/]/).pop()}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {isImageJob && (
                <div>
                    <h3 className="font-semibold text-sm text-brand-accent mb-2 uppercase">AI Generated Result</h3>
                    <div className="relative aspect-square w-full bg-brand-primary rounded-lg border border-slate-700/50 flex items-center justify-center overflow-hidden">
                        {job.isLoading && <LoadingSpinner />}
                        {job.editedResult?.image && !job.isLoading && (
                            <img src={`data:image/png;base64,${job.editedResult.image}`} alt="Edited result" className="w-full h-full object-contain" />
                        )}
                        {!job.isLoading && !job.editedResult?.image && !job.error && (
                            <div className="text-slate-400">Awaiting generated image...</div>
                        )}
                    </div>
                </div>
            )}

            {!isImageJob && job.isLoading && (
                <div className="relative p-8 bg-brand-primary rounded-lg border border-slate-700/50 min-h-[100px] flex items-center justify-center">
                    <LoadingSpinner />
                </div>
            )}

            {job.error && (
                <div className="bg-red-900/50 border border-red-700 text-red-200 px-3 py-2 rounded-md text-sm" role="alert">
                    <strong>Error:</strong> {job.error}
                </div>
            )}

            {job.editedResult?.text && !job.isLoading && (
                <div className="p-3 bg-brand-primary rounded-md border border-slate-700/50">
                    <h3 className="font-semibold text-xs text-brand-accent mb-1 uppercase">AI Response</h3>
                    <p className="text-brand-text text-sm whitespace-pre-wrap">{job.editedResult.text}</p>
                </div>
            )}
        </div>
    );
};

export default JobCard;