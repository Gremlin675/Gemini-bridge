
import React from 'react';
import { ConnectionStatus as ConnectionStatusEnum } from '../types';

interface ConnectionStatusProps {
    status: ConnectionStatusEnum;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({ status }) => {
    const statusConfig = {
        [ConnectionStatusEnum.CONNECTED]: {
            text: 'Connected',
            bgColor: 'bg-green-500/20',
            textColor: 'text-green-300',
            dotColor: 'bg-green-400',
            animate: false,
        },
        [ConnectionStatusEnum.DISCONNECTED]: {
            text: 'Disconnected',
            bgColor: 'bg-red-500/20',
            textColor: 'text-red-300',
            dotColor: 'bg-red-400',
            animate: false,
        },
        [ConnectionStatusEnum.CONNECTING]: {
            text: 'Connecting...',
            bgColor: 'bg-yellow-500/20',
            textColor: 'text-yellow-300',
            dotColor: 'bg-yellow-400',
            animate: true,
        },
    };

    const config = statusConfig[status];

    return (
        <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-full text-sm font-medium ${config.bgColor} ${config.textColor}`}>
            <span className={`h-2 w-2 rounded-full ${config.dotColor} ${config.animate ? 'animate-pulse' : ''}`}></span>
            <span>{config.text}</span>
        </div>
    );
};

export default ConnectionStatus;
