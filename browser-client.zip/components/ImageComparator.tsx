
import React, { useState, useRef, useCallback, useEffect } from 'react';

interface ImageComparatorProps {
    original: string;
    edited?: string;
    isLoading?: boolean;
}

const LoadingSpinner: React.FC = () => (
    <div className="absolute inset-0 flex items-center justify-center bg-brand-secondary/80 backdrop-blur-sm z-30">
        <div className="flex flex-col items-center">
            <svg className="animate-spin h-10 w-10 text-brand-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-4 text-lg font-medium text-brand-text">Editing with AI...</p>
        </div>
    </div>
);

const ImageComparator: React.FC<ImageComparatorProps> = ({ original, edited, isLoading = false }) => {
    const [sliderPosition, setSliderPosition] = useState(50);
    const [isDragging, setIsDragging] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    const handleMove = useCallback((clientX: number) => {
        if (!isDragging || !containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
        const percent = (x / rect.width) * 100;
        setSliderPosition(percent);
    }, [isDragging]);

    const handleMouseDown = (e: React.MouseEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleTouchStart = (e: React.TouchEvent) => {
        setIsDragging(true);
    };

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
    }, []);

    const handleTouchEnd = useCallback(() => {
        setIsDragging(false);
    }, []);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        handleMove(e.clientX);
    }, [handleMove]);

    const handleTouchMove = useCallback((e: TouchEvent) => {
        handleMove(e.touches[0].clientX);
    }, [handleMove]);

    useEffect(() => {
        if (isDragging) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
            window.addEventListener('touchmove', handleTouchMove);
            window.addEventListener('touchend', handleTouchEnd);
        } else {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
            window.removeEventListener('touchmove', handleTouchMove);
            window.removeEventListener('touchend', handleTouchEnd);
        }

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
            window.removeEventListener('touchmove', handleTouchMove);
            window.removeEventListener('touchend', handleTouchEnd);
        };
    }, [isDragging, handleMouseMove, handleMouseUp, handleTouchMove, handleTouchEnd]);

    const labels = (
        <div className="absolute top-0 left-0 w-full h-full z-20 pointer-events-none">
            <div className="absolute top-2 left-2 px-2 py-1 bg-black/50 text-white text-xs font-bold rounded">BEFORE</div>
            <div className="absolute top-2 right-2 px-2 py-1 bg-black/50 text-white text-xs font-bold rounded">AFTER</div>
        </div>
    );
    
    return (
        <div 
            ref={containerRef}
            className="relative w-full aspect-square select-none rounded-lg overflow-hidden shadow-lg border-2 border-slate-700/50"
        >
             {isLoading && <LoadingSpinner />}
            <img 
                src={original} 
                alt="Original" 
                className="absolute w-full h-full object-contain pointer-events-none"
                draggable={false}
            />

            {edited && (
                <>
                    <div 
                        className="absolute w-full h-full object-contain overflow-hidden pointer-events-none"
                        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
                    >
                         <img 
                            src={edited} 
                            alt="Edited" 
                            className="absolute w-full h-full object-contain pointer-events-none"
                            draggable={false}
                        />
                    </div>
                    <div 
                        className="absolute top-0 bottom-0 w-1 bg-brand-accent/50 cursor-ew-resize z-10"
                        style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
                        onMouseDown={handleMouseDown}
                        onTouchStart={handleTouchStart}
                    >
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-8 w-8 bg-brand-accent rounded-full flex items-center justify-center shadow-lg">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5 text-brand-primary"><path d="M8 17l-5-5 5-5M16 7l5 5-5 5"/></svg>
                        </div>
                    </div>
                </>
            )}

            {!isLoading && edited && labels}

            {!isLoading && !edited && (
                 <div className="w-full h-full flex items-center justify-center text-slate-400 bg-brand-secondary">
                    Awaiting edited image...
                </div>
            )}
        </div>
    );
};

export default ImageComparator;
